package ir.thapad.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.BufferedWriter
import java.io.OutputStreamWriter
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import org.xml.sax.helpers.AttributesImpl
import javax.xml.parsers.SAXParserFactory

data class Post(val id: Long, val code: String, val place: String, val hours: Int, val date: String, val note: String)

class DbHelper(c: android.content.Context) : SQLiteOpenHelper(c, "thapad.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE posts(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL, place TEXT NOT NULL, hours INTEGER NOT NULL, date TEXT NOT NULL, note TEXT)")
        db.execSQL("CREATE TABLE locations(name TEXT PRIMARY KEY)")
        listOf("موسوی","خرازی","صدر زاده","طهرانی مقدم","موقعیت حسین","پاسبخش","مرفوک").forEach {
            val v=ContentValues(); v.put("name",it); db.insert("locations",null,v)
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun locations(): List<String> {
        val out=mutableListOf<String>(); readableDatabase.rawQuery("SELECT name FROM locations ORDER BY rowid",null).use { while(it.moveToNext()) out.add(it.getString(0)) }; return out
    }
    fun addLocation(name:String) { val v=ContentValues(); v.put("name",name); writableDatabase.insertWithOnConflict("locations",null,v,SQLiteDatabase.CONFLICT_IGNORE) }
    fun save(p:Post) {
        val v=ContentValues().apply { put("code",p.code); put("place",p.place); put("hours",p.hours); put("date",p.date); put("note",p.note) }
        if(p.id==0L) writableDatabase.insert("posts",null,v) else writableDatabase.update("posts",v,"id=?", arrayOf(p.id.toString()))
    }
    fun delete(id:Long) { writableDatabase.delete("posts","id=?", arrayOf(id.toString())) }
    fun posts(code:String="", date:String=""):List<Post> {
        val clauses=mutableListOf<String>(); val args=mutableListOf<String>()
        if(code.isNotBlank()){ clauses.add("code LIKE ?"); args.add("%$code%") }
        if(date.isNotBlank()){ clauses.add("date=?"); args.add(date) }
        val q="SELECT id,code,place,hours,date,note FROM posts"+if(clauses.isEmpty()) "" else " WHERE "+clauses.joinToString(" AND ")+" ORDER BY date DESC,id DESC"
        val out=mutableListOf<Post>(); readableDatabase.rawQuery(q,args.toTypedArray()).use { while(it.moveToNext()) out.add(Post(it.getLong(0),it.getString(1),it.getString(2),it.getInt(3),it.getString(4),it.getString(5) ?: "")) }; return out
    }
}

class MainActivity : Activity() {
    private lateinit var db: DbHelper
    private val navy=Color.rgb(17,28,46); private val panel=Color.rgb(35,52,75); private val gold=Color.rgb(214,180,106); private val pale=Color.rgb(238,241,246)
    private var exportCode=""
    private val createXlsx = 7001
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); db=DbHelper(this); home() }
    private fun dp(n:Int)= (n*resources.displayMetrics.density).toInt()
    private fun base(title:String):LinearLayout {
        val outer=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(navy); layoutDirection=View.LAYOUT_DIRECTION_RTL }
        val header=TextView(this).apply { text=title; textSize=22f; setTextColor(Color.WHITE); gravity=Gravity.CENTER; setPadding(8,dp(22),8,dp(18)); setTypeface(null,1) }
        outer.addView(header)
        val scroll=ScrollView(this); val content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(8),dp(18),dp(24)); layoutDirection=View.LAYOUT_DIRECTION_RTL }
        scroll.addView(content); outer.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(outer); return content
    }
    private fun txt(s:String,size:Float=15f,color:Int=Color.WHITE):TextView = TextView(this).apply { text=s; textSize=size; setTextColor(color); setPadding(0,dp(7),0,dp(7)); gravity=Gravity.RIGHT }
    private fun field(hint:String,value:String=""):EditText = EditText(this).apply {
        setSingleLine(true); this.hint=hint; setText(value); textSize=16f; setTextColor(Color.WHITE); setHintTextColor(0xFFB8C3D1.toInt())
        setPadding(dp(12),dp(8),dp(12),dp(8)); backgroundTintList=android.content.res.ColorStateList.valueOf(gold)
    }
    private fun btn(label:String, action:()->Unit):Button = Button(this).apply {
        text=label; isAllCaps=false; textSize=15f; setTextColor(navy); setBackgroundTintList(android.content.res.ColorStateList.valueOf(gold))
        setOnClickListener { action() }; layoutParams=LinearLayout.LayoutParams(-1,dp(52)).apply { topMargin=dp(8); bottomMargin=dp(5) }
    }
    private fun addField(parent:LinearLayout,label:String,edit:EditText) { parent.addView(txt(label,14f,0xFFD6B46A.toInt())); parent.addView(edit) }
    private fun home() {
        val c=base("ثپد")
        c.addView(txt("سامانه مدیریت و ثبت پست",14f,0xFFB8C3D1.toInt()).apply { gravity=Gravity.CENTER; setPadding(0,0,0,dp(22)) })
        btn("＋  ثبت پستی جدید") { form() }; btn("▤  خروجی اکسل") { output() }; btn("✎  ویرایش و حذف") { manage() }
        c.addView(txt("اطلاعات روی همین گوشی ذخیره می‌شود.",12f,0xFF9EACBE.toInt()).apply { gravity=Gravity.CENTER; setPadding(0,dp(22),0,0) })
    }
    private fun form(existing:Post?=null) {
        val c=base(if(existing==null) "ثبت پستی جدید" else "ویرایش پست")
        val code=field("کد شناسایی",existing?.code ?: ""); addField(c,"کد شناسایی",code)
        c.addView(txt("موقعیت"))
        val locs=db.locations().toMutableList()
        val sp=Spinner(this); sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,locs)
        val locWrap=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        locWrap.addView(sp,LinearLayout.LayoutParams(0,dp(52),1f))
        val add=Button(this).apply { text="＋"; setTextColor(navy); setBackgroundTintList(android.content.res.ColorStateList.valueOf(gold)); setOnClickListener {
            val e=EditText(this@MainActivity).apply { hint="نام موقعیت جدید" }
            AlertDialog.Builder(this@MainActivity).setTitle("افزودن موقعیت").setView(e).setPositiveButton("ذخیره"){_,_-> val n=e.text.toString().trim(); if(n.isNotEmpty()){ db.addLocation(n); form(existing) } }.setNegativeButton("انصراف",null).show()
        }}
        locWrap.addView(add,LinearLayout.LayoutParams(dp(60),dp(52))); c.addView(locWrap)
        if(existing!=null) sp.setSelection(locs.indexOf(existing.place).coerceAtLeast(0))
        c.addView(txt("مدت ساعت"))
        val hours=Spinner(this); val hlist=listOf("۶ ساعت","۱۲ ساعت","۲۴ ساعت"); hours.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,hlist); c.addView(hours)
        if(existing!=null) hours.setSelection(listOf(6,12,24).indexOf(existing.hours).coerceAtLeast(0))
        val date=field("مثلاً ۱۴۰۵/۰۸/۱۹",existing?.date ?: ""); addField(c,"تاریخ (شمسی)",date)
        val note=EditText(this).apply { hint="توضیحات"; setText(existing?.note ?: ""); minLines=3; gravity=Gravity.TOP or Gravity.RIGHT; setTextColor(Color.WHITE); setHintTextColor(0xFFB8C3D1.toInt()); backgroundTintList=android.content.res.ColorStateList.valueOf(gold) }
        addField(c,"توضیحات",note)
        btn(if(existing==null) "ذخیره پست" else "ذخیره تغییرات") {
            val cd=code.text.toString().trim(); val dt=date.text.toString().trim()
            if(cd.isEmpty() || dt.isEmpty()) { Toast.makeText(this,"کد شناسایی و تاریخ الزامی است",Toast.LENGTH_LONG).show(); return@btn }
            val hrs=listOf(6,12,24)[hours.selectedItemPosition]
            db.save(Post(existing?.id ?: 0L,cd,locs[sp.selectedItemPosition],hrs,dt,note.text.toString().trim()))
            Toast.makeText(this,"اطلاعات ذخیره شد",Toast.LENGTH_SHORT).show(); home()
        }
        btn("بازگشت") { home() }
    }
    private fun manage() {
        val c=base("ویرایش و حذف")
        val code=field("جستجو با کد شناسایی"); val date=field("تاریخ دقیق، مثلاً ۱۴۰۵/۰۸/۱۹")
        addField(c,"کد شناسایی",code); addField(c,"تاریخ",date)
        val results=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        fun refresh() {
            results.removeAllViews()
            val rows=db.posts(code.text.toString().trim(),date.text.toString().trim())
            if(rows.isEmpty()) results.addView(txt("موردی پیدا نشد",14f,0xFFB8C3D1.toInt()))
            rows.forEach { p ->
                val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),dp(10),dp(12),dp(10)); setBackgroundColor(panel) }
                card.addView(txt("کد: ${p.code}   •   ${p.date}",16f,gold)); card.addView(txt("${p.place}  |  ${p.hours} ساعت",14f))
                if(p.note.isNotBlank()) card.addView(txt(p.note,13f,0xFFCFD6E0.toInt()))
                card.addView(btn("ویرایش"){ form(p) })
                card.addView(btn("حذف"){ AlertDialog.Builder(this).setMessage("این پست حذف شود؟").setPositiveButton("حذف"){_,_->db.delete(p.id);refresh()}.setNegativeButton("انصراف",null).show() })
                results.addView(card); results.addView(View(this).apply { minimumHeight=dp(10) })
            }
        }
        btn("جستجو") { refresh() }; c.addView(results); refresh(); btn("بازگشت"){home()}
    }
    private fun output() {
        val c=base("خروجی اکسل")
        val from=field("از تاریخ، مثلاً ۱۴۰۵/۰۸/۰۱"); val to=field("تا تاریخ، مثلاً ۱۴۰۵/۰۸/۳۰"); val code=field("کد شناسایی (اختیاری)")
        addField(c,"از تاریخ",from); addField(c,"تا تاریخ",to); addField(c,"جستجو بر اساس کد شناسایی",code)
        btn("ساخت فایل Excel") {
            val a=from.text.toString().trim(); val b=to.text.toString().trim(); val cd=code.text.toString().trim()
            val rows=db.posts(cd).filter { (a.isBlank() || it.date>=a) && (b.isBlank() || it.date<=b) }
            if(rows.isEmpty()){ Toast.makeText(this,"در این بازه اطلاعاتی پیدا نشد",Toast.LENGTH_LONG).show(); return@btn }
            exportCode=cd
            val intent=Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"; putExtra(Intent.EXTRA_TITLE,"Thapad-report.xlsx") }
            pendingRows=rows
            startActivityForResult(intent,createXlsx)
        }
        btn("بازگشت"){home()}
        c.addView(txt("ستون‌های فایل: کد شناسایی، جمع ساعت، تعداد مراجعه به هر موقعیت، توضیحات",12f,0xFFB8C3D1.toInt()))
    }
    private var pendingRows:List<Post> = emptyList()
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==createXlsx && resultCode==RESULT_OK) {
            val uri=data?.data ?: return
            try { contentResolver.openOutputStream(uri)?.use { writeXlsx(it,pendingRows) }; Toast.makeText(this,"فایل اکسل ذخیره شد",Toast.LENGTH_LONG).show() }
            catch(e:Exception){ Toast.makeText(this,"خطا در ساخت فایل: ${e.message}",Toast.LENGTH_LONG).show() }
        }
    }
    private fun esc(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;")
    private fun writeXlsx(out:java.io.OutputStream, rows:List<Post>) {
        val places=db.locations()
        val grouped=rows.groupBy{it.code}.toSortedMap()
        val matrix=mutableListOf<List<String>>()
        matrix.add(listOf("کد شناسایی","جمع ساعت")+places.map{"تعداد مراجعه: $it"}+listOf("توضیحات"))
        grouped.forEach { (code,items) ->
            matrix.add(listOf(code,items.sumOf{it.hours}.toString())+places.map{p->items.count{it.place==p}.toString()}+listOf(items.mapNotNull{it.note.takeIf{n->n.isNotBlank()}}.distinct().joinToString(" | ")))
        }
        val zip=ZipOutputStream(out)
        fun entry(name:String,content:String){ zip.putNextEntry(ZipEntry(name)); zip.write(content.toByteArray(Charsets.UTF_8)); zip.closeEntry() }
        entry("[Content_Types].xml","""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
        entry("_rels/.rels","""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
        entry("xl/workbook.xml","""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="گزارش ثپد" sheetId="1" r:id="rId1"/></sheets></workbook>""")
        entry("xl/_rels/workbook.xml.rels","""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
        val sheet=StringBuilder("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""")
        matrix.forEachIndexed { ri,row ->
            sheet.append("<row r=\"${ri+1}\">")
            row.forEachIndexed { ci,value ->
                var n=ci; var col=""
                do { col=('A'.code+n%26).toChar()+col; n=n/26-1 } while(n>=0)
                sheet.append("<c r=\"$col${ri+1}\" t=\"inlineStr\"><is><t>${esc(value)}</t></is></c>")
            }
            sheet.append("</row>")
        }
        sheet.append("</sheetData></worksheet>")
        entry("xl/worksheets/sheet1.xml",sheet.toString())
        zip.finish(); zip.flush()
    }
}
